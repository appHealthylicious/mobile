package com.dicoding.picodiploma.loginwithanimation.data.response

import com.dicoding.picodiploma.loginwithanimation.data.pref.UserProfile

data class ProfileResponse(
	val userProfile: UserProfile? = null
)
