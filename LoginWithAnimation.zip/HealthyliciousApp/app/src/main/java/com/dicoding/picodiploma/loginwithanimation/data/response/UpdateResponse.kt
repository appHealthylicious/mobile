package com.dicoding.picodiploma.loginwithanimation.data.response

data class UpdateResponse(
    val message: String? = ""
)

data class ErrorResponse(
    val error: String? = ""
)