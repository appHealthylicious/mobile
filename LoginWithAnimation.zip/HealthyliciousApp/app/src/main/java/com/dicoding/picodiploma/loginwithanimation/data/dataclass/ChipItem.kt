package com.dicoding.picodiploma.loginwithanimation.data.dataclass

data class ChipItem(
    val text: String,
    val chipItems: List<String?>
)
